/*
Assignment 2
VUID: Bc190404195
Name: Muhammad Waqas Nazir

*/

#include<iostream>
using namespace std;

class Queue // <--- Defining Queue Class For Storing Data --->
{
	public:
		int age,blood,heart,covid;
		string name,gender;
		Queue *next_add;
};

class Patient // <-- Defining Linked List Class For Storing Nodes --->
{
	private: 
		Queue *head = NULL;
		
	public:
		// <--- Function for list class --->
		void insert(); 
		void display();
		void count();
};

	void Patient::insert()
	{
		
		int pa,bs,hd,cp; // <--- Here i am using pa(patient Age), bs (Blood suger), hd(Heart Decease), cp(Covid Patients) --->
		string pn,pg;	// <--- Here i am using pn(patient name), pg(patient gender) --->
	
		// --- Taking Patient Information ---
		cout<<"\n\t\t\t\t Enter Patient's Information";
		cout<<"\n\n Name : ";
		cin>>pn;
		cout<<"\n Age : ";
		cin>>pa;
		cout<<"\n Gender : ";
		cin>>pg;
		cout<<"\n Blood Sugar (1 for Positive 0 for Negtive) : ";
		cin>>bs;
		cout<<"\n Heart Decease (1 for Positive 0 for Negtive) : ";
		cin>>hd;
		cout<<"\n\n COVID-19 (1 for Positive 0 for Negtive) : ";
		cin>>cp;
		
		
		// --- Insertion of Record into Node ---
		Queue *new_node = new Queue;
		new_node -> name = pn;
		new_node -> age = pa;
		new_node -> gender = pg;
		new_node -> blood = bs;
		new_node -> heart = hd;
		new_node -> covid = cp;
		new_node -> next_add = NULL;
		
		// --- Adding Node into the Linked List ---
		if(head == NULL)
		head = new_node;
		else
		{
			// --- Checking the  Last Node ---
			Queue *ptr = head;
			while(ptr -> next_add != NULL)
			{
				ptr = ptr -> next_add;
			}
			ptr -> next_add = new_node;
		}
		cout<<"\n Patient Added Successfully";
	}
	void Patient::display()
	{
		cout<<"\n\t\t\t\t All Patients Information";
		Queue *ptr = head;
		while(ptr != NULL)
		{
			cout<<"\n Name : "<<ptr -> name;
			cout<<"\n Age : "<<ptr -> age;
			cout<<"\n Gender : "<<ptr -> gender;
			(ptr -> blood == 1) ? cout<<"\n Blood Sugar : Positive" : cout<<"\n\n Blood Sugar : Negtive"; 
			(ptr -> heart == 1) ? cout<<"\n Heart Decease : Positive" : cout<<"\n\n Heart Decease : Negtive";
			(ptr -> covid == 1) ? cout<<"\n COVID-19 : Positive" : cout<<"\n\n COVID-19 : Negtive";
			cout<<"\n\n ";
			ptr = ptr -> next_add;
		}
	}
	void Patient::count()
	{
		int male,female,kids, old, bs, hd, cp, hrisk;
		male=female=kids=old=bs=hd=cp=hrisk=0;

		cout<<"\n\n\n\t\t\t\t --------- Counted Information ---------";
		Queue *ptr = head;
		
		while(ptr != NULL)
		{
			if(ptr -> gender == "Male" || ptr -> gender == "male"|| ptr -> gender == "MALE")
			male++;
			else
			female++;
			if(ptr -> age < 15)
			kids++;
			else if(ptr -> age > 50)
			old++;
			if(ptr -> blood == 1)
			bs++;
			if(ptr -> heart == 1)
			hd++;
			if(ptr -> covid == 1)
			cp++;
			if(ptr -> blood == 1 && ptr -> heart == 1 && ptr -> covid == 1 && ptr -> age > 50)
			hrisk++;
			ptr = ptr -> next_add;
		}
		cout<<"\n\n Number Of Male Patients : "<<male;
		cout<<"\n Number Of Female Patients : "<<female;
		cout<<"\n Number Of Kids Patients : "<<kids;
		cout<<"\n Number Of Patients Have Age Over 50 : "<<old;
		cout<<"\n Number Of Patients Have Blood Sugar Decease : "<<bs;
		cout<<"\n Number Of Patients Have Heart Decease : "<<hd;
		cout<<"\n Number Of Patients Have COVID-19 : "<<cp;
		cout<<"\n\n Number Of High Risk Patients : "<<hrisk;
	}
	
	// <--- Here is the  Main Function --->
int main() 
{
	Patient l;
	char choice;
	// <--- Calling the Insert Function --->
	do
	{
		l.insert();
		cout<<"\n\n Do You Want enter Another Patient? input y or Y for Yes and n or N for No (Y | N) :  ";
		cin>>choice;
	}while(choice == 'y' || choice == 'Y');
	
	//	--- Calling the Display Function  ---
	l.display();
	
	// --- Calling Count Information Function ---
	l.count();
	return 0;
}


